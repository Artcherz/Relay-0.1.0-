# Relay M4 Durable Plan

- Schema version: `1.0.0`
- Run ID: `run-m4-live`
- Status: `SUCCEEDED`
- Overall objective: Add priority support to the task service while preserving TaskService.create(title).
- Source baseline: `f9947d962139a1e3f7ce1acdaf52ea04f371cddd`
- Routing policy: `m3-capability-routing-v1`
- Concurrency policy: `m4-parallel-fanout-v1`
- Maximum concurrent workers: 2
- Worker execution order: `T001 -> (T002 || T003)`
- Deterministic integration order: `T001 -> T002 -> T003`
- Integration-order rule: `m4-integrate-tests-before-documentation`
- Planner model: `gpt-5.6-sol`
- Planner reasoning effort: `medium`
- Planner thread ID hash: `91224299e097fa07943789273dcb19ec6bd694704f525e918b069006b29e2a1b`
- Planner input tokens: 34239
- Planner cached input tokens: 9984
- Planner output tokens: 1639
- Planner reasoning tokens: 444
- Planner output schema digest: `c8e13f3f10b8b4a093cbe421ecf78149b103c7f5f90b02cbcfad853ad2d2c16a`
- Planner semantic output digest: `f87e88d3056c6a1e0ec4affa17d73d42d119e701a7c6fc8acbbab3a0e0a21ea5`
- Planning context manifest digest: `1d734fa2ee9a29a0481861c762e25d16303cd481a6e4b9a624d5f0dffd80b149`
- Planner validation accepted: yes
- Parent conversation included: no
- Fresh planner thread: yes
- Controller policy digest: `1df875bf6cf2983c4aae0ffe6e54447a7408d1697377226b9dd24eab46072bdd`
- Assembled controller policy digest: `1df875bf6cf2983c4aae0ffe6e54447a7408d1697377226b9dd24eab46072bdd`
- Controller policy digests match: yes
- Controller dependency-policy digest: `06ceb732229425f690324e4d8c1b4add67c35a29919349ee03a25bfb3da5585a`
- Assembled dependency-policy digest: `06ceb732229425f690324e4d8c1b4add67c35a29919349ee03a25bfb3da5585a`
- Dependency-policy digests match: yes
- Graph provenance digest: `ad3362312542f1947eddbe88a78e4f91be3fa64f98e53c11a1c7fae615c6b19c`
- Run policy digest: `e9994d8dfd5d130ca302fe5d5dbf24442794ce0ecc5ee00116b8fa9b0601b48b`
- Controller toolchain evidence digest: `9bd498e7949315702cceb3377b7f7bdd7ee1330d69170c7dfbd2358f7cb693a6`
- Controller Python version: `Python 3.11.15`
- Controller pytest version: `pytest 9.1.1`
- Controller Ruff version: `ruff 0.15.22`
- Controller toolchain path persisted or supplied to a worker: no

- T001 canonical contract digest: `3bf8d09cfb9e4b0d21c27698fc3d069b33803a6a095db09bbb0417a18183a837`
- T001 field-provenance digest: `4ad55c29bb6c51b2c0450f7bd6c3981239ddbd80713b572ce794de7aee3bc001`
- T002 canonical contract digest: `2611332ee422b9723bd57a8b67ddbb4f3a55517a5a344b4fe59b8eba598d6736`
- T002 field-provenance digest: `4ad55c29bb6c51b2c0450f7bd6c3981239ddbd80713b572ce794de7aee3bc001`
- T003 canonical contract digest: `bdc7b0faac508b4f50bba31958cb6c5fab3829490b7bb680e2bc5c4ed1b87ee8`
- T003 field-provenance digest: `4ad55c29bb6c51b2c0450f7bd6c3981239ddbd80713b572ce794de7aee3bc001`

Sol produced bounded semantic decomposition. Relay supplied the safe executable graph, paths,
routing, acceptance gates, status transitions, Git authority, integration, compaction, and cleanup.

## Plan summary

Add in-memory task priorities with backward-compatible creation, strict validation, optional filtering, focused regression tests, and concise README usage examples.

## Controlled graph

- T001 (core-implementation): depends on none; sequential predecessor none.
- T002 (test-coverage): depends on T001; sequential predecessor T001.
- T003 (documentation): depends on T001; sequential predecessor T002.

## Active tasks

| ID | Task | Model | Effort | Depends on | Status |
| --- | --- | --- | --- | --- | --- |
| T001 | Implement task priority behavior | Terra | medium | — | INTEGRATED |
| T002 | Cover priority compatibility and edge cases | Luna | medium | T001 | INTEGRATED |
| T003 | Document priority usage | Luna | low | T001 | INTEGRATED |

<!-- relay-task-status:T001:INTEGRATED -->
<!-- relay-task-status:T002:INTEGRATED -->
<!-- relay-task-status:T003:INTEGRATED -->

## Global constraints

- After T001 cleanup, execute T002 and T003 concurrently in isolated worktrees.
- Workers edit ordinary permitted files, leave changes unstaged, and never create commits.
- Relay independently validates, commits, integrates, compacts, and cleans each task.
- Integrate only in controller-fixed `T001 -> T002 -> T003` order, never completion order.
- Export detailed sanitized evidence before compaction and task cleanup.
- No worker may install packages, modify dependency manifests, or introduce an unapproved import.
- No retry, repair, escalation, or adaptive routing is enabled.

## Final acceptance gates

- Final fixture pytest passes through the controller toolchain.
- Final Ruff passes through the controller toolchain.
- All three controller commits are integrated in order.
- Exactly three digest-backed ledger entries exist.
- Every ledger entry references one durable external evidence-bundle digest.
- Final run-directory enumeration is exactly `["PLAN.md"]`.

## Completed-task ledger

<!-- relay-task:T001:digest:8b624deb4944dd2085c7000cf47e5d5a1d54eee92e2073a43a4844d92b7e074e -->
### T001 — Implement task priority behavior

- Task key: `core-implementation`
- Requested model: `gpt-5.6-terra`
- Requested reasoning effort: `medium`
- Actual execution adapter: `codex-sdk-worker`
- Actual provider call: openai-codex
- Actual model: gpt-5.6-terra
- Selected authentication mode: `codex-login`
- Credential kind: `chatgpt-login`
- Billing class: `chatgpt-plan-or-credits`
- Credential material persisted by Relay: no
- Worker SDK version: `0.144.4`
- Worker Codex runtime version: `0.144.4`
- Worker thread ID hash: `231a3149b503a469b5e72928878ce0bc079aa4f157733674f10a9bfbcbf2c97c`
- Worker context manifest digest: `916b7bae6f2709e891b00826a813626a51a1c5301c09a34180f8dd82776a5dde`
- Worker output schema digest: `21118f14ee8a4778b467463ecaee99daa1b79a6777d69b9a37419da60c1b16a4`
- Worker completion-report digest: `2743b80062dfdc8ecba885cfb80bb6e2196a1cdd1d38f21e26c362484b00a04d`
- Parent conversation included: no
- Fresh worker thread: yes
- Attempt: 1
- Worker implementation disposition: `READY_FOR_CONTROLLER_VALIDATION`
- Worker self-check disposition: `PARTIAL`
- Worker self-check summary: Manual Python 3 smoke check passed for default, low/high, filtering, invalid creation/filter rejection, no mutation, and sequential IDs. pytest and ruff are unavailable in the sandbox.
- Worker self-check authority: non-authoritative
- Controller acceptance authority: authoritative
- Controller toolchain path supplied to worker: no
- Worker created task commit: no
- Changed files: `src/task_service/service.py`
- Filesystem changes produced by: `gpt-5.6-terra`
- Task commit created by: `relay-controller`
- Controller-created task commit: `91cabd9f9d391ac281163c1f508a13909e12f0e6`
- Pre-validation snapshot digest: `f30ac3dd9e99358bdcd3c035402fb42688e4f9ece2b9533f204ed473077539a0`
- Post-validation snapshot digest: `f30ac3dd9e99358bdcd3c035402fb42688e4f9ece2b9533f204ed473077539a0`
- Validation snapshots match: yes
- Validated worktree snapshot digest: `f30ac3dd9e99358bdcd3c035402fb42688e4f9ece2b9533f204ed473077539a0`
- Committed content digest: `d13e2a24ba164529ced5ac8ffa226caf67e99ed62360ed53509aa05a651d4938`
- Controller commit hooks disabled: yes
- Controller commit signing disabled: yes
- Controller commit identity: `Relay Controller <relay-controller@localhost.invalid>`
- Global Git configuration changed: no
- Pre-integration commit: `f9947d962139a1e3f7ce1acdaf52ea04f371cddd`
- Post-integration commit: `711731ebe5a30022aa8f4fd8f96f1cd5e6c83aa3`
- Integration outcome: INTEGRATED
- Final acceptance: PASSED
- External evidence bundle: `tasks/T001/evidence.json`
- External evidence-bundle digest: `85dfb9091b8b8f529fe4c1d164103c4da43266521b45621024eb2039d86a5b98`
- Input tokens: 135916
- Cached input tokens: 115712
- Output tokens: 3071
- Reasoning tokens: 847
- Model cost: unavailable
- Validation:
  - worker-result-schema: PASS
  - worker-result-identity: PASS
  - worker-status: PASS
  - required-outputs: PASS
  - worker-head: PASS
  - worker-head-unchanged: PASS
  - worker-index-unchanged: PASS
  - git-derived-changes: PASS
  - worker-reported-files-untrusted: PASS
  - write-scope: PASS
  - dirty-worktree-expected: PASS
  - integration-branch-unchanged: PASS
  - fixture-tests: PASS
  - ruff: PASS
  - conflict-preflight: PASS
  - worktree-snapshot-stable: PASS
  - dependency-policy: PASS
  - service-priority-contract: PASS
  - m3-task-snapshot-stable: PASS
  - post-integration-tests: PASS
  - post-integration-ruff: PASS
- Compaction digest: `8b624deb4944dd2085c7000cf47e5d5a1d54eee92e2073a43a4844d92b7e074e`
<!-- relay-task-end:T001 -->

<!-- relay-task:T002:digest:47eee12c8419fa57dc7ddc240d4a76af22464c0fa29796c965bf8f3caa56fd08 -->
### T002 — Cover priority compatibility and edge cases

- Task key: `test-coverage`
- Requested model: `gpt-5.6-luna`
- Requested reasoning effort: `medium`
- Actual execution adapter: `codex-sdk-worker`
- Actual provider call: openai-codex
- Actual model: gpt-5.6-luna
- Selected authentication mode: `codex-login`
- Credential kind: `chatgpt-login`
- Billing class: `chatgpt-plan-or-credits`
- Credential material persisted by Relay: no
- Worker SDK version: `0.144.4`
- Worker Codex runtime version: `0.144.4`
- Worker thread ID hash: `398ed71f71950ee134fb56ad8c557fb26a7ba52aed95d447b093e7f9e8f88d4c`
- Worker context manifest digest: `dd610fe934e9ea38da76e8097cbba99c056272f71589c3f6d5a27d1de8d879e6`
- Worker output schema digest: `21118f14ee8a4778b467463ecaee99daa1b79a6777d69b9a37419da60c1b16a4`
- Worker completion-report digest: `bceb78705c3c4a5b59aa987547fd2933f775631108d95ba1d30bcc4d1cb6c842`
- Parent conversation included: no
- Fresh worker thread: yes
- Attempt: 1
- Worker implementation disposition: `READY_FOR_CONTROLLER_VALIDATION`
- Worker self-check disposition: `PARTIAL`
- Worker self-check summary: git diff --check passed. pytest, Ruff, and Python compilation were unavailable because the commands were not installed.
- Worker self-check authority: non-authoritative
- Controller acceptance authority: authoritative
- Controller toolchain path supplied to worker: no
- Worker created task commit: no
- Changed files: `tests/test_service.py`
- Filesystem changes produced by: `gpt-5.6-luna`
- Task commit created by: `relay-controller`
- Controller-created task commit: `22f78f48671e54ea286b41771e5bc11894903700`
- Pre-validation snapshot digest: `b9a7e244812113deacff72caac7cfe06778dd7e09feae8ae9f40d088882d062e`
- Post-validation snapshot digest: `b9a7e244812113deacff72caac7cfe06778dd7e09feae8ae9f40d088882d062e`
- Validation snapshots match: yes
- Validated worktree snapshot digest: `b9a7e244812113deacff72caac7cfe06778dd7e09feae8ae9f40d088882d062e`
- Committed content digest: `3bb8776d0ee89f0f86173699d920429e0d081fc81e2d5f4a8d24371030186fde`
- Controller commit hooks disabled: yes
- Controller commit signing disabled: yes
- Controller commit identity: `Relay Controller <relay-controller@localhost.invalid>`
- Global Git configuration changed: no
- Pre-integration commit: `711731ebe5a30022aa8f4fd8f96f1cd5e6c83aa3`
- Post-integration commit: `0f7fa558727d977f1e963a41fcc42010ef4205b4`
- Integration outcome: INTEGRATED
- Final acceptance: PASSED
- External evidence bundle: `tasks/T002/evidence.json`
- External evidence-bundle digest: `2057c00fd5309e5261090bfbfdd694be41259d64beedfc39ac4d4ea9354cc368`
- Input tokens: 79515
- Cached input tokens: 62208
- Output tokens: 1927
- Reasoning tokens: 314
- Model cost: unavailable
- Validation:
  - worker-result-schema: PASS
  - worker-result-identity: PASS
  - worker-status: PASS
  - required-outputs: PASS
  - worker-head: PASS
  - worker-head-unchanged: PASS
  - worker-index-unchanged: PASS
  - git-derived-changes: PASS
  - worker-reported-files-untrusted: PASS
  - write-scope: PASS
  - dirty-worktree-expected: PASS
  - integration-branch-unchanged: PASS
  - fixture-tests: PASS
  - ruff: PASS
  - conflict-preflight: PASS
  - worktree-snapshot-stable: PASS
  - dependency-policy: PASS
  - test-coverage-contract: PASS
  - dependency-baseline: PASS
  - m3-task-snapshot-stable: PASS
  - post-integration-tests: PASS
  - post-integration-ruff: PASS
- Compaction digest: `47eee12c8419fa57dc7ddc240d4a76af22464c0fa29796c965bf8f3caa56fd08`
<!-- relay-task-end:T002 -->

<!-- relay-task:T003:digest:6b5f8e27d9c9bf8a75ffbe9f3fe5340e7123f8c667c6bf681351ec5aa3c1292d -->
### T003 — Document priority usage

- Task key: `documentation`
- Requested model: `gpt-5.6-luna`
- Requested reasoning effort: `low`
- Actual execution adapter: `codex-sdk-worker`
- Actual provider call: openai-codex
- Actual model: gpt-5.6-luna
- Selected authentication mode: `codex-login`
- Credential kind: `chatgpt-login`
- Billing class: `chatgpt-plan-or-credits`
- Credential material persisted by Relay: no
- Worker SDK version: `0.144.4`
- Worker Codex runtime version: `0.144.4`
- Worker thread ID hash: `2c81650254801cb08212c6bc03fd3a5387ed43bc8bb1d63475a5d0c3e7fd305d`
- Worker context manifest digest: `1f51e74053a45486fa1eac500ed7b1f18c05c3feb132363db090eefa468f7929`
- Worker output schema digest: `21118f14ee8a4778b467463ecaee99daa1b79a6777d69b9a37419da60c1b16a4`
- Worker completion-report digest: `658c6ddcb863d46297a1455d1951ecf7fa3fb746ba1eafbecd68c2d92481fc06`
- Parent conversation included: no
- Fresh worker thread: yes
- Attempt: 1
- Worker implementation disposition: `READY_FOR_CONTROLLER_VALIDATION`
- Worker self-check disposition: `PASSED`
- Worker self-check summary: Python examples parsed successfully with python3 and git diff --check passed. The python command was unavailable, so python3 was used.
- Worker self-check authority: non-authoritative
- Controller acceptance authority: authoritative
- Controller toolchain path supplied to worker: no
- Worker created task commit: no
- Changed files: `README.md`
- Filesystem changes produced by: `gpt-5.6-luna`
- Task commit created by: `relay-controller`
- Controller-created task commit: `2bde0f635c1f8c07a70f145b2a4b46264862ad58`
- Pre-validation snapshot digest: `9a1ef56bb120ebdf172bc5c464ee2697918754be329e1c4d5c8358ce8684fe8d`
- Post-validation snapshot digest: `9a1ef56bb120ebdf172bc5c464ee2697918754be329e1c4d5c8358ce8684fe8d`
- Validation snapshots match: yes
- Validated worktree snapshot digest: `9a1ef56bb120ebdf172bc5c464ee2697918754be329e1c4d5c8358ce8684fe8d`
- Committed content digest: `e62b9658a48841325e5f66d668587b30224f512dd7789029bd39b6a12515c795`
- Controller commit hooks disabled: yes
- Controller commit signing disabled: yes
- Controller commit identity: `Relay Controller <relay-controller@localhost.invalid>`
- Global Git configuration changed: no
- Pre-integration commit: `0f7fa558727d977f1e963a41fcc42010ef4205b4`
- Post-integration commit: `24929777804baa67c4fe8614dee36d26669b86f6`
- Integration outcome: INTEGRATED
- Final acceptance: PASSED
- External evidence bundle: `tasks/T003/evidence.json`
- External evidence-bundle digest: `796e30b6ed3409726cc31805803754beea61a586b71efa977278c51a72573a38`
- Input tokens: 63064
- Cached input tokens: 47104
- Output tokens: 1102
- Reasoning tokens: 132
- Model cost: unavailable
- Validation:
  - worker-result-schema: PASS
  - worker-result-identity: PASS
  - worker-status: PASS
  - required-outputs: PASS
  - worker-head: PASS
  - worker-head-unchanged: PASS
  - worker-index-unchanged: PASS
  - git-derived-changes: PASS
  - worker-reported-files-untrusted: PASS
  - write-scope: PASS
  - dirty-worktree-expected: PASS
  - integration-branch-unchanged: PASS
  - fixture-tests: PASS
  - ruff: PASS
  - conflict-preflight: PASS
  - worktree-snapshot-stable: PASS
  - dependency-policy: PASS
  - documentation-contract: PASS
  - dependency-baseline: PASS
  - m3-task-snapshot-stable: PASS
  - documentation-controller-commit-parent: PASS
  - documentation-controller-commit-scope: PASS
  - documentation-production-behavior-unchanged: PASS
  - documentation-conflict-preflight-current-integration: PASS
  - documentation-contract-current-integration: PASS
  - post-integration-tests: PASS
  - post-integration-ruff: PASS
  - final-fixture-tests: PASS
  - final-ruff: PASS
- Compaction digest: `6b5f8e27d9c9bf8a75ffbe9f3fe5340e7123f8c667c6bf681351ec5aa3c1292d`
<!-- relay-task-end:T003 -->

<!-- relay-ledger-end -->

Final acceptance: PASSED.
  - final-fixture-tests: PASS
  - final-ruff: PASS

<!-- relay-run-complete:digest:94344bd73698a971b77165bd2d23741462120b573f368d29f315ddabf8499859 -->
