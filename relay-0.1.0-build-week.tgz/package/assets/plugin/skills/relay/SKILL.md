---
name: relay
description: Launch and inspect durable, independently verified Relay coding workflows.
---

# Relay

Use the installed `relay` CLI as the authority. Preserve the user's request exactly when handing it to Relay.

1. Confirm the current repository and explain the supported modes: replay, deterministic local, or the controlled `python-task-service` live profile.
2. For free inspection run `relay demo --replay`; for a zero-model lifecycle run `relay demo --local`.
3. For live work, show the selected authentication mode, supported profile, and usage warning before invoking `relay run` with explicit confirmation.
4. Return the run identifier or path, durable `PLAN.md` location, status, evidence location, and dashboard URL printed by the CLI.
5. Route status, evidence, plugin, and recovery guidance through Relay commands. Load `references/commands.md` only when command detail is needed.

Never expose credentials, copy a parent transcript into worker context, edit an active task packet, approve a worker, create its commit, integrate it, compact it, or delete it. Relay runtime authority is final.
