# Relay commands

- `relay demo --replay`: accepted sanitized evidence; no credentials, Git writes, or model calls.
- `relay demo --local`: disposable deterministic lifecycle; no credentials or model calls.
- `relay doctor`: zero-turn prerequisite report.
- `relay status --run <path>`: read-only status.
- `relay evidence list|verify|open`: read-only evidence inspection.
- `relay run --profile python-task-service ... --confirm-live`: optional supported live profile.
- `relay demo --live --auth codex-login --confirm-live`: copy the bundled fixture and run the
  complete four-turn controlled profile.
- `relay dashboard --run <run-or-PLAN> --evidence-root <root>`: inspect validated active, recovery,
  PLAN-only, and indexed external evidence.

Replay is recorded evidence, local workers are deterministic adapters, and live mode consumes the user's selected Codex allowance or API usage.
