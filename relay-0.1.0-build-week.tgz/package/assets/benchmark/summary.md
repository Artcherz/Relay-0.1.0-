# Relay M5 controlled benchmark

Both the accepted M4.1 mixed-tier strategy and the M5 all-Sol strategy passed the same frozen controller acceptance suite in this single benchmark case.

## Measured facts

- Mixed-tier worker usage: 278,495 input, 225,024 cached input, 6,100 output, and 1,293 reasoning tokens.
- All-Sol worker usage: 229,384 input, 172,800 cached input, 6,933 output, and 1,230 reasoning tokens.
- Mixed-tier worker lifecycle: 136,416 ms; all-Sol worker lifecycle: 139,045 ms.
- The escalation drill used CONTROLLED_FAULT_INJECTION; Luna passed naturally and naturalModelFailure is false.
- The repair used one fresh Terra/medium thread in the same dirty worktree, followed by complete controller revalidation and one controller commit.

## Estimated values

Using rate card codex-token-credits-2026-07-17, mixed-tier worker execution is estimated at 14.66168 Codex credits and all-Sol worker execution at 36.03275. The controlled difference is 21.37107 credits, or 59.31012759225983% of the all-Sol estimate. With the identical historical planning usage added to both sides, the estimates are 20.295605 and 41.666675.

These are estimates from recorded Codex-login token usage, not observed billing or monetary cost. Reported output tokens already include generated reasoning tokens, so reasoning tokens are recorded separately and not added again.

## Limitations and non-claims

This is one controlled fixture and does not establish universal savings, general model rankings, or that every task should use a smaller model. The 2,461 ms worker-phase difference is recorded but is not claimed as a speedup. The controlled fault proves one validation-triggered Luna-to-Terra repair path; it does not establish that Luna naturally failed. Relay still has no learned routing, arbitrary escalation, provider retry, dashboard streaming, or production billing integration.
