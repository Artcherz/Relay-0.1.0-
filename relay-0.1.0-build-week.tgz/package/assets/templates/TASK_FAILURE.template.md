## Validation failure — attempt {{ATTEMPT}}

- Time: `{{TIMESTAMP}}`
- Check: `{{CHECK_NAME}}`
- Command: `{{COMMAND}}`
- Exit status: `{{EXIT_STATUS}}`

### Bounded evidence

{{EVIDENCE}}

### Required correction

{{CORRECTION}}

### Routing action

{{ROUTING_ACTION}}
