# Relay Execution Plan

## Run

- Schema version: `1.0.0`
- Run ID: `{{RUN_ID}}`
- Created: `{{CREATED_AT}}`
- Repository: `{{REPOSITORY}}`
- Baseline commit: `{{BASELINE_COMMIT}}`
- Mode: `{{MODE}}`
- Routing policy: `{{ROUTING_POLICY_VERSION}}`
- Status: `PLANNED`

## Objective

{{OBJECTIVE}}

## Global constraints

{{GLOBAL_CONSTRAINTS}}

## Task graph

| ID            | Task | Model | Reasoning | Dependencies | Write scope | Status |
| ------------- | ---- | ----- | --------- | ------------ | ----------- | ------ |
| {{TASK_ROWS}} |

## Frozen interfaces

{{FROZEN_INTERFACES}}

## Final acceptance gates

{{FINAL_ACCEPTANCE_GATES}}

## Completed task ledger

No task has been verified and integrated yet.

For profiles with external evidence export, each completed ledger entry must contain exactly one
sanitized evidence-bundle identifier and digest before its task packet may be deleted.

## Blocked or unresolved work

None.

## Resource summary

Populated from verified telemetry at finalization. Missing values must be labeled unavailable.

## Final result

Not finalized.
