# Relay Final Report

- Run: `{{RUN_ID}}`
- Final status: `{{STATUS}}`
- Baseline commit: `{{BASELINE_COMMIT}}`
- Final integration commit: `{{FINAL_COMMIT}}`

## Acceptance results

{{ACCEPTANCE_RESULTS}}

## Model usage

{{MODEL_USAGE}}

## Cost, tokens, and time

{{RESOURCE_SUMMARY}}

## Recovery and escalation

{{RECOVERY_SUMMARY}}

## Known limitations

{{LIMITATIONS}}

This report is temporary input to final `PLAN.md` compaction and should not remain after successful finalization.
