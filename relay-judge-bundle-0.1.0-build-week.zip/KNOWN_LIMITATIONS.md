# Known limitations

- Live execution supports only the controlled `python-task-service` fixture/profile; arbitrary repositories, graphs, task types, routes, and providers are rejected.
- API-key mode is offline-tested, not live-tested.
- Linux x86_64 is the only tested platform; Windows, macOS, and ARM are unverified.
- Replay is recorded evidence and local mode uses deterministic adapters.
- The M5 credit comparison is one controlled estimate, not billing or a universal ranking.
- The dashboard is local single-user software, not a hardened remote service.
- Automatic resume is not supported. Failure-preserved packets and worktrees remain for explicit manual recovery.
- Historical M6.1–M6.6 blocked runs remain truthful failure evidence and were never promoted. The
  separate final M6.7 installed-package lifecycle passed without retry.
- Static hosting is optional and is not part of the local release. Video upload, Devpost submission,
  repository publication/sharing, and `/feedback` remain entrant actions.
