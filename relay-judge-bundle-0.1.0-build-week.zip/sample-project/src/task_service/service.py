from dataclasses import dataclass


@dataclass(frozen=True)
class Task:
    id: int
    title: str


class TaskService:
    def __init__(self) -> None:
        self._tasks: list[Task] = []

    def create(self, title: str) -> Task:
        clean_title = title.strip()
        if not clean_title:
            raise ValueError("title must not be empty")

        task = Task(id=len(self._tasks) + 1, title=clean_title)
        self._tasks.append(task)
        return task

    def list(self) -> list[Task]:
        return list(self._tasks)
