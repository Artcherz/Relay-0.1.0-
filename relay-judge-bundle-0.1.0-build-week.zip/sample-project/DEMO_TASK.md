# Demo Task

Add priority support to the task service without breaking existing clients.

## Required behavior

1. A task may have priority `low`, `normal`, or `high`.
2. Existing calls that omit priority must behave as `normal`.
3. Invalid priorities must be rejected without mutating stored tasks.
4. Listing may optionally filter by one priority.
5. Existing tests must continue to pass.
6. Add automated tests for default priority, validation, and filtering.
7. Update the README with concise examples.

## Global constraints

- Preserve the existing `TaskService.create(title)` call form.
- Do not add a database or external dependency.
- Do not rewrite unrelated code.
- The final result must pass `pytest` and `ruff check .`.

## Intended decomposition for the demo

The planner is free to produce a better graph, but a valid graph should expose at least:

- interface/data-model task;
- service implementation task;
- test task;
- documentation task;
- final integration gate.

At least two tasks should be independently executable after the interface is frozen.
