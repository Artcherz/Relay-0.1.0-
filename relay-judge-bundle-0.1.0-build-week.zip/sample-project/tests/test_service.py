import pytest

from task_service import TaskService


def test_create_and_list_tasks() -> None:
    service = TaskService()

    created = service.create("Prepare demo")

    assert created.id == 1
    assert created.title == "Prepare demo"
    assert service.list() == [created]


def test_empty_title_is_rejected_without_mutation() -> None:
    service = TaskService()

    with pytest.raises(ValueError, match="title must not be empty"):
        service.create("   ")

    assert service.list() == []
