# Relay Demo Repository

A deliberately small Python service used to demonstrate planning, parallel task execution, validation, recovery, and integration.

## Baseline behavior

The service stores tasks in memory and supports creation and listing. The competition demo asks Relay to add priorities, filtering, tests, and documentation without breaking existing behavior.

## Setup

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e '.[test]'
pytest
```

The Relay demo script should copy this fixture to a disposable location and initialize a fresh Git repository before every benchmark run.
